package com.Project1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.catalina.valves.rewrite.Substitution.StaticElement;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Servlet implementation class Otp
 */
@WebServlet("/otp")
public class Otp extends HttpServlet {
	static int  i;
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		for(int i=0;i<3;i++) {
	i=Integer.parseInt(request.getParameter("otp"));
	boolean b =true;
	if(b=(CodeWord.getOtp()==i)) {
		System.out.println(b);
		Logger log=Logger.getLogger(Landing.class);
		 String log4jConfPath = "/home/venkat-zstk271/eclipse-workspace/CalorieCounter/src/main/java/log4j.properties";
	       PropertyConfigurator.configure(log4jConfPath);
	       log.info("Your otp is correct");
		login obj1= new login();
		try {
			obj1.loginuser(Landing.con,response);
			Cookie ck = new Cookie("cookey","true");
		    ck.setMaxAge(24*60*60); 
		    System.out.println(ck);
		    System.out.println("otp");
		    response.addCookie(ck);
		    RequestDispatcher rDispatcher = request.getRequestDispatcher("FetchDetails.html");
	        rDispatcher.forward(request, response);
		} catch (NoSuchAlgorithmException | SQLException e) {
		       PropertyConfigurator.configure(log4jConfPath);
		       log.debug("cookie is not added");
		}
	}
	else {
	   System.out.println("otp wrong");
	   response.sendRedirect("otp.html");
	}
	}
		 RequestDispatcher rDispatcher = request.getRequestDispatcher("FetchDetails.html");
	     rDispatcher.forward(request, response);
	}
}
