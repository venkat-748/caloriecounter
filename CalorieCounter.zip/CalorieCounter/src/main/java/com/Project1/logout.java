package com.Project1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import org.json.simple.JSONObject;

/**
 * Servlet implementation class logout
 */

public class logout extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JSONObject jo = new JSONObject();
		PrintWriter out = response.getWriter();
		jo.put("status","true");
		Cookie[] ckCookie =request.getCookies();
	    for(Cookie ck:ckCookie) {
	    	ck.setMaxAge(0);
	    }
		response.sendRedirect("Index.html");
		out.write(jo.toJSONString());
		out.flush();
	}

}
