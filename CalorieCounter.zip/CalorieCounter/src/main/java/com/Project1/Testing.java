package com.Project1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.catalina.core.ApplicationFilterChain;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
@WebFilter("/Signup")
public class Testing extends HttpFilter {
	Logger log=Logger.getLogger(FetchDetails.class);
	 String log4jConfPath = "/home/venkat-zstk271/eclipse-workspace/CalorieCounter/src/main/java/log4j.properties";
	 
	
	public void doFilter(HttpServletRequest request, HttpServletResponse response, ApplicationFilterChain chain) throws IOException, ServletException {
		 System.out.println("testing...............");
		 boolean checkMail= Pattern.matches("\\\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,4}\\\\b", request.getParameter("email"));
		 boolean checkPassword = Pattern.matches("\" ^[a-zA-Z](?=.*\\\\\\\\d)(?=.*[a-z])(?=.*[A-Z]).{7,14}\"", request.getParameter("pass"));
		 boolean checkName = Pattern.matches("[a-zA-z_]*",request.getParameter("uname"));
		 boolean checkDob= Pattern.matches("\\d{4}-\\d{2}-\\d{2}", request.getParameter("dob"));
		 boolean checkCalorie = Pattern.matches("[0-9]{10}", request.getParameter("calorie"));
		 if(checkMail&&checkPassword&&checkName&&checkDob&&checkCalorie) {
			 chain.doFilter(request, response);
		 }
		
		
	}
}
