package com.Project1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Signin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("welcome");
		Logger log=Logger.getLogger(Signin.class);
		 String log4jConfPath = "/home/venkat-zstk271/eclipse-workspace/CalorieCounter/src/main/java/log4j.properties";
		 PropertyConfigurator.configure(log4jConfPath);
		String email =request.getParameter("email");
		String password = request.getParameter("pass");
		
		try {
			boolean condition=Landing.signinCheck(email,password);
			System.out.println(condition);
			if(condition) {
				System.out.println("hello in sign in");
				Cookie ck = new Cookie("cookey","true");
			    ck.setMaxAge(24*60*60); 
			   
			    response.addCookie(ck);
			response.sendRedirect("welcome.jsp");
						}
			
		} catch (NoSuchAlgorithmException | SQLException e) {
		       log.debug("cookie is setted");
		} catch (ClassNotFoundException e) {
			   log.debug("class nit found");
		}
	}

}
