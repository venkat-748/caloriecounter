package com.Project1;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;

public class FetchDetails extends HttpServlet {
	Logger log=Logger.getLogger(FetchDetails.class);
	 String log4jConfPath = "/home/venkat-zstk271/eclipse-workspace/CalorieCounter/src/main/java/log4j.properties";
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hello iam in fetchdetails");
		int age = Integer.parseInt(request.getParameter("age"));
		String food = request.getParameter("items").toUpperCase();
		String [] items =food.split(",");
		PrintWriter out = response.getWriter();
		List<JSONObject>list=new ArrayList<>();
		int total=0;
		try {			
			
			connect(items,response,request);
		
			
		
		}catch (ClassNotFoundException | SQLException e) {
			   PropertyConfigurator.configure(log4jConfPath);
		       log.debug("class not found");
		}
		out.print("</p>total calorie</p>"+total+"</><br></p>");
		if(age>=19&&age<=30) {
			if(total<2400) {
				out.print("<p>You need more food to increase your calorie</p>");
			}
			else if(total>2400&&total<3000) {
				out.print("<p>Your food is sufficient to increase calorie per day</p>");
			}
			else {
				out.print("<p>you less your food it is more sufficience</p>");
			}
		}
		else if(age>=31&&age<=59) {
			if(total<2200) {
				out.print("<p>You need more food to increase your calorie</p>");
			}
			else if(total>2200&&total<3000) {
				out.print("<p>Your food is sufficient to increase calorie per day</p>");
			}
			else {
				out.print("<p>you less your food it is more sufficience</p>");
			}
		}
		else if(age>=60) {
			if(total<2000) {
				out.print("<p>You need more food to increase your calorie</p>");
			}
			else if(total>2000&&total<2600) {
				out.print("<p>Your food is sufficient to increase calorie per day</p>");
			}
			else {
				out.print("<p>you less your food it is more sufficience</p>");
			}
		}  
		}
		
	
	
	private void connect(String [] items,HttpServletResponse response,HttpServletRequest request) throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
	 ServletContext context = request.getServletContext();
	    String db=context.getInitParameter("db");
	    String user=context.getInitParameter("user");
	    System.out.println(db);
	    System.out.println(user);
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+db,user,"");
	
		PreparedStatement stmt = con.prepareStatement("select calorie,details,nutritionalScore from nutritionFood where name =?");
		List<JSONObject>json=new ArrayList<>();
		for(int i=0;i<items.length;i++) {
		stmt.setString(1, items[i]);
		System.out.println(stmt);
		ResultSet rs = stmt.executeQuery();
		JSONObject jo=new JSONObject();
		while(rs.next()) {
			jo.put("name",items[i]);
			jo.put("Calories",rs.getString(1));
			jo.put("Details",rs.getString(2));
			jo.put("Nutritions",rs.getString(3));
			json.add(jo);
		}
		}
		System.out.println("----->"+json.toString());
		PrintWriter out = response.getWriter();
		String [] printing = json.toString().split(",");
		for(JSONObject x:json) {
			String [] arr = x.toString().split(",");
			for(String j:arr)
				out.println("<p>"+j+"<p>");
		}
	   
		
		out.flush();
		out.close();
        
	
	}

	

}
