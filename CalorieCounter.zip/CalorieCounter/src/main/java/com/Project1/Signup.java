package com.Project1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Servlet implementation class Signup
 */

public class Signup extends HttpServlet {
	Logger log=Logger.getLogger(Signup.class);
	String log4jConfPath = "/home/venkat-zstk271/eclipse-workspace/CalorieCounter/src/main/java/log4j.properties";
	private static final long serialVersionUID = 1L;
	HttpServletResponse response;
	HttpServletRequest request;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("signup");
		PropertyConfigurator.configure(log4jConfPath);
		this.response=response;
		this.request=request;
	     String email= request.getParameter("email");
	     String password= request.getParameter("pass");
	     String uname= request.getParameter("uname");
	     String dob= request.getParameter("dob");
	     int calorie = Integer.parseInt(request.getParameter("calorie"));
	     try {
			if(checking(email,password,uname,dob,calorie)) {
				response.sendRedirect("otp.html");
			}
		} catch (ClassNotFoundException | NoSuchAlgorithmException | SQLException e) {
			log.debug("checking method is not calling");
			e.printStackTrace();
		} 
	}
	public boolean checking(String email, String password, String uname, String dob,int calorie) throws ClassNotFoundException, SQLException, NoSuchAlgorithmException, IOException, ServletException {
	PreparedStatement stmt ;
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/calorie","root","");
	log.info("get Connection From database");
	stmt = con.prepareStatement("select email_xyq from users");
	System.out.println(stmt);
	ResultSet rs = stmt.executeQuery();
	boolean duplicate = false;
	while (rs.next()) {
		if(rs.getString(1).equals(Landing.email)) {
			System.out.println(rs.getString(1));
			duplicate=true;
			break;
		}
		else {
			System.out.println(rs.getString(1));
			System.out.println("sucesss........");
			
		}
	}
	if(!duplicate) {
		System.out.println("no duplicate");
		Landing obj = new Landing(email,password,uname,dob,calorie);
	}
	else {
	System.out.println("not correct");
	 RequestDispatcher rd = request.getRequestDispatcher("Signin.html");
     rd.forward(request, response);
	System.out.println("hello");
	}
	return true;	
}
}
