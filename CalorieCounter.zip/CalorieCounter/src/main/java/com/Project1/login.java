package  com.Project1;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.ws.Response;

import org.apache.catalina.ha.backend.Sender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.x.protobuf.MysqlxCrud.Insert;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletResponse;

public class login {
	Logger log=Logger.getLogger(login.class);
	 String log4jConfPath = "/home/venkat-zstk271/eclipse-workspace/CalorieCounter/src/main/java/log4j.properties";
     
	boolean loginuser(Connection con,HttpServletResponse response) throws SQLException, NoSuchAlgorithmException, IOException {
		System.out.println("coming");
		PreparedStatement stmt = con.prepareStatement("insert into users values(?,?,?,?,?,?,?)");
		System.out.println(stmt);
		stmt.setString(1,Landing.userid);
		stmt.setString(2,Landing.uname);
		stmt.setString(3,Landing.email);
		stmt.setString(4,Landing.dob);
		stmt.setString(5, Landing.bio);
		stmt.setString(6, Landing.hashPassword(Landing.password));
		stmt.setInt(7,Landing.calorie);
		System.out.println(stmt);
		int i=stmt.executeUpdate();
		System.out.println(i);
		if(i==1) {
			System.out.println("hello");
		       PropertyConfigurator.configure(log4jConfPath);
		       log.debug("the value is insert into database");
			return true;
		}
		else {
			System.out.println("bad");
		       PropertyConfigurator.configure(log4jConfPath);
		       log.debug("the value is insert into database");
		return false;
		
	}
	}



}
